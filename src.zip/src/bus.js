import Vue from 'vue'
const Bus = new Vue()
export default Bus