'use strict'
module.exports = {
    NODE_ENV: '"production"',
    MGR_PATH: '"./mgr"'
}
